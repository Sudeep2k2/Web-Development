import React from "react";
import './App.css';
import Leftside from "./components/Leftside";

function App() {
  return (
    <>
      <Leftside/>
    </>
  );
}

export default App;