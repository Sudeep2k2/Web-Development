import React from "react";
import Msssg from "./Messages.png"
import Tr from "./Trending.png"
import Notif from "./Notifications.png"
import Posts from "./Posts.png"
import Prof from "./Profile.png"
import More from "./More.png"

export default function Leftside() {
  return (
    <div className="LSM">
      <div className="Navbar">
        <div className="Name">
          <div className="AN">
            Twinsta
          </div>
        </div>
        <div className="Search">
          <form>
            <div>
              <input type="search" id="mySearch" name="q" placeholder="Search the site…" />
              <button>Search</button>
            </div>
          </form>
        </div>
        <div className="msg">
          <img src={Msssg} alt="mssgs"/>
          <div classname = "tags">Messages</div>
        </div>
      </div>
      <div className="LSS">
        <div className="TRENDING">
          <img src = {Tr} alt = "Trending"/>
          <div classname = "tags">Trending</div>
        </div>
        <div className="Notifications">
          <img src = {Notif} alt = "Notifications"/>
          <div classname = "tags">Notifications</div>
        </div>
        <div className="Posts">
          <img src = {Posts} alt = "Posts"/>
          <div classname = "tags">Posts</div>
        </div>
        <div className="Profile">
          <img src = {Prof} alt = "Profile"/>
          <div classname = "tags">Profile</div>
        </div>
        <div className="More">
          <img src = {More} alt = "More"/>
          <div className = "tags">More</div>
        </div>
      </div>
    </div>
  )
}